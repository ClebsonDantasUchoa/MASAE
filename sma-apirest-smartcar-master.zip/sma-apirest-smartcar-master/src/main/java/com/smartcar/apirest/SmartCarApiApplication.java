package com.smartcar.apirest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartCarApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartCarApiApplication.class, args);
	}

}
